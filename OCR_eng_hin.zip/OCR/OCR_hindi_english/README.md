---
title: OCR Hindi English
emoji: 😻
colorFrom: purple
colorTo: blue
sdk: gradio
sdk_version: 4.44.0
app_file: app.py
pinned: false
short_description: 'ocr model for text recognition '
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
